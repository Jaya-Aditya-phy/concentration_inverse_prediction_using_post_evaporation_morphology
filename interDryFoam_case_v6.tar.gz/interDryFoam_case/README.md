# interDryFoam — axisymmetric-wedge droplet evaporation with full physics coupling

Extends `interFoam` (VOF, two-phase, laminar Navier-Stokes) with:

| Added physics | File | Source-of-truth equation |
|---|---|---|
| Glycerol transport | `CmEqn.H` | advection-diffusion, D from `transportProperties` |
| Local viscosity μ(Cm) | `createFields.H` / `CmEqn.H` | `cheng2008Viscosity()` = `glycerol_viscosity()` in `lab_labeler.py`, transcribed 1:1 |
| Local surface tension σ(Cm) | `createFields.H` / `CmEqn.H` | linear mix, same constants as `marangoni_number()` in `feature_extractor.py` |
| Marangoni tangential force | `marangoniForce.H`, called from `UEqn.H` | projects out interface-normal component of ∇σ, localizes by \|∇α1\| |
| Particle transport | `CpEqn.H` | Stokes-Einstein D(Cm), continuum jamming hindrance `(1-Cp/Cp_jam)^n` |
| Raoult's-law evaporation | `alphaEqn.H` | local water-activity-driven interface sink |

## Why this instead of the BRW

The lattice-BRW's rush-hour mechanism never fired because `PACKING_PHI_JAM`
was defined on a discrete lattice-site occupancy fraction that structurally
never reached the jamming threshold on a coarse grid — a resolution
artifact, not a physics failure. Here `Cp` is a genuine continuum particle
volume fraction, so `Cp_jam = 0.64` (actual random-close-packing) is a
physically reachable number. If jamming-driven acceleration is real, it
should now show up as an actual diffusive-flux collapse in `CpEqn.H`, not
get lost in lattice coarseness.

## Build

```bash
# from inside the interDryFoam/ subdirectory
wmake
```

**Before this compiles**, you WILL need to reconcile a few things against
your installed OpenFOAM version (ESI vs Foundation, version number) —
flagged inline with comments wherever they matter:

1. `createFields.H` — the exact base mixture class name
   (`immiscibleIncompressibleTwoPhaseMixture` vs `twoPhaseMixture`) and how
   your version reads `transportPropertiesDict()`. Copy your installed
   `interFoam/createFields.H`'s alpha/rho/U/p_rgh block verbatim, then paste
   in everything below the `---- interDryFoam additions ----` marker here.
2. `pEqn.H` — currently a stub pointing at your stock file. Grep it for
   `surfaceTensionForce`/`sigma` — if it recomputes the surface tension term
   a second time (some versions do, for the `phig` flux correction), mirror
   the normal+tangential split from `UEqn.H` there too.
3. `alphaEqn.H` — the MULES advection substep itself is left as stock
   (don't hand-roll a flux limiter); only the evaporation sink at the bottom
   is new.
4. `Make/options` — library names for `twoPhaseMixture` /
   `immiscibleIncompressibleTwoPhaseMixture` vary by version; check
   `$FOAM_SOLVERS/multiphase/interFoam/Make/options` and match it.

## Run one condition

```bash
blockMesh
setFields          # edit setFieldsDict's Cm/Cp values first for this condition
interDryFoam
```

## Calibration — do this BEFORE trusting any Pe/Ma comparison

`evapRateCoeff` in `transportProperties` is a free constant. Run a pure-water
condition (`Cm=0` everywhere) and tune `evapRateCoeff` until the liquid
volume (logged live via the `liquidVolume` function object in
`controlDict`) reaches zero at `t ≈ EVAP_TIME_S = 1800s`, matching the
experimental evaporation time this whole pipeline already assumes. Every
downstream cross-condition Pe/Ma comparison depends on this being right —
it's the continuum-solver equivalent of the BRW's `N_REPLICATES` ensemble
averaging: a single un-calibrated constant that silently sets the scale of
everything else if you skip checking it.

## Known gaps / honest limitations

- **`pEqn.H` sigma double-counting risk** (see build note #2) — if missed,
  Marangoni force gets added in `UEqn.H` but partially cancelled or
  double-applied in the pressure correction. Check this first if results
  look physically wrong (e.g. spurious currents at the interface — a
  classic VOF+surface-tension symptom, worse when σ is a field not a
  constant).
- **Raoult sink is a local mass-fraction proxy, not molar activity** — same
  approximation level already accepted in `evap_physics.py`, stated
  explicitly here so it doesn't quietly become a stronger claim than the
  rest of your pipeline supports.
- **Wedge angle (5°) assumes true axisymmetry** — any genuinely
  non-axisymmetric effect (asymmetric drying, off-center contact-line
  pinning) is excluded by construction. If Paper 2's real time-lapse data
  ever shows asymmetric ring formation, this solver can't capture it and
  you'd need the full 3D mesh you originally asked about.
- **Coupling to `feature_extractor.py`** — this solver outputs continuum
  fields (`Cp`, `alpha1`), not tile images. You'll need a post-processing
  step that renders `Cp` (deposited/settled fraction) into the same
  center/N/S/E/W tile geometry `render_particle_deposit()` used for the
  BRW, so the 40D feature vector stays comparable across BRW and CFD runs.
  Not written yet — flag if you want this next, it's a genuinely separate
  (much smaller) script.
