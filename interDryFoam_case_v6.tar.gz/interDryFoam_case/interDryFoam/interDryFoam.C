/*----------------------------------------------------------------------------*\
  interDryFoam

  interFoam (VOF, two incompressible phases, laminar) extended with:
    - Cm  : glycerol mass fraction transport (advection-diffusion)
    - Cp  : particle concentration transport, with a jamming-aware
            effective diffusivity (continuum "rush hour" replacement for
            the lattice-BRW's mobility_hindrance(phi))
    - local mu(Cm)   via the Cheng (2008) correlation (glycerol_viscosity()
                       in lab_labeler.py, transcribed verbatim)
    - local sigma(Cm) driving a genuine tangential Marangoni force at the
                       VOF interface (in addition to interFoam's native
                       normal curvature force)
    - a Raoult's-law-corrected local evaporation sink at the interface

  Build:  copy this whole directory next to your case, then:
      wmake

  This file follows the standard interFoam main-loop skeleton. Sections
  marked "STOCK" should be copied verbatim from your installed
  $FOAM_SOLVERS/multiphase/interFoam/interFoam.C -- API details (createPhi.H
  contents, EEqn presence, etc.) vary enough across OpenFOAM
  versions/forks (ESI vs Foundation, v8 vs v2306...) that hand-transcribing
  them here risks silently using a stale API. Everything ADDED for this
  project is written out in full below.
\*----------------------------------------------------------------------------*/

#include "fvCFD.H"
#include "dynamicFvMesh.H"
#include "CMULES.H"
#include "EulerDdtScheme.H"
#include "localEulerDdtScheme.H"
#include "CrankNicolsonDdtScheme.H"
#include "subCycle.H"
#include "immiscibleIncompressibleTwoPhaseMixture.H"
#include "turbulentTransportModel.H"
#include "pimpleControl.H"
#include "fvOptions.H"
#include "CorrectPhi.H"
#include "fvcSmooth.H"

#include "marangoniForce.H"   // added: Marangoni tangential-force function

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{
    #include "postProcess.H"

    #include "setRootCaseLists.H"
    #include "createTime.H"
    #include "createDynamicFvMesh.H"     // STOCK
    #include "initContinuityErrs.H"
    #include "createDyMControls.H"       // STOCK
    #include "createFields.H"            // MODIFIED: see interDryFoam/createFields.H
    #include "createUfIfPresent.H"       // STOCK
    #include "CorrectPhi.H"              // STOCK

    turbulence->validate();

    if (!LTS)
    {
        #include "CourantNo.H"
        #include "setInitialDeltaT.H"
    }

    // * * * * * * * * * * * * * * * * * * * * * * * * Time loop * * * * * //

    Info<< "\nStarting time loop\n" << endl;

    while (pimple.run(runTime))
    {
        #include "readDyMControls.H"

        if (LTS)
        {
            #include "setRDeltaT.H"
        }
        else
        {
            #include "CourantNo.H"
            #include "alphaCourantNo.H"
            #include "setDeltaT.H"
        }

        ++runTime;

        Info<< "Time = " << runTime.timeName() << nl << endl;

        // --- mesh motion / topo-change hooks, STOCK if you use a moving mesh
        //     (not required here: droplet shrinkage is captured by VOF
        //     alpha1 retreating on a FIXED mesh, no deforming boundary)

        while (pimple.loop())
        {
            #include "alphaEqn.H"    // MODIFIED: adds Raoult evaporation sink
            #include "CmEqn.H"       // ADDED: glycerol transport + mu/D/sigma updates
            #include "CpEqn.H"       // ADDED: particle transport, jamming-aware D
            #include "UEqn.H"        // MODIFIED: adds Marangoni tangential force

            while (pimple.correct())
            {
                #include "pEqn.H"    // STOCK (verify sigma usage per note in pEqn.H)
            }

            if (pimple.turbCorr())
            {
                turbulence->correct();
            }
        }

        runTime.write();

        Info<< "ExecutionTime = " << runTime.elapsedCpuTime() << " s"
            << "  ClockTime = " << runTime.elapsedClockTime() << " s"
            << nl << endl;
    }

    Info<< "End\n" << endl;

    return 0;
}

// ************************************************************************* //
